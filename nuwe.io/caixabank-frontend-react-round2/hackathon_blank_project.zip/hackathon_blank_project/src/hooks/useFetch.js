import { useState, useEffect } from "react";

// TODO: Implement the `useFetch` hook to fetch data from the provided URL.
const useFetch = (url) => {
  return { data, error, isLoading };
};

export default useFetch;
