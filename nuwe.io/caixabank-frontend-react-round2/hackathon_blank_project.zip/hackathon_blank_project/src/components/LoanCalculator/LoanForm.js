import React, { useState } from "react";
import { TextField, Button, Typography, Box } from "@mui/material";

const LoanForm = ({ onCalculate }) => {
  const [amount, setAmount] = useState(null);
  const [rate, setRate] = useState(null);
  const [duration, setDuration] = useState(null);
  const [error, setError] = useState("");

  const handleCalculate = () => {
    // TODO: Validate that `amount`, `rate`, and `duration` are positive, non-null numbers. Show an error message if validation fails.
    onCalculate(amount, rate, duration);
  };

  // TODO: Bind values to the TextFields, set correct `type` attributes, and ensure proper functions are triggered for all components.
  return (
    <Box display="flex" flexDirection="column" gap={2}>
      <TextField
        type=""
        label="Loan Amount (EUR)"
        variant="outlined"
        value={amount}
        onChange={}
        data-testid="loan-amount-input"
      />
      <TextField
        type=""
        label="Annual Interest Rate (%)"
        variant="outlined"
        value={}
        onChange={(e) => setRate(e.target.value)}
        data-testid="loan-rate-input"
      />
      <TextField
        type=""
        label="Duration (Months)"
        variant="outlined"
        value={}
        onChange={}
        data-testid="loan-duration-input"
      />
      <Button
        variant="contained"
        color="primary"
        onClick={}
        data-testid="calculate-button"
        sx={{ width: 200 }}
      >
        Calculate
      </Button>
      {error && (<Typography color="error" data-testid="error-message">{error}</Typography>)}
    </Box>
  );
};

export default LoanForm;
