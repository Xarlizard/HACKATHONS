import React from "react";
import { Box, Typography, Paper } from "@mui/material";

const LoanResults = ({ monthlyPayment, totalPayment }) => {
  // TODO: Display `monthlyPayment` and `totalPayment` formatted to two decimal places.
  return (
    <Paper elevation={3} sx={{ mt: 2 }} data-testid="loan-results">
      <Box p={2}>
        <Typography variant="h6" gutterBottom>Results</Typography>
        <Typography data-testid="monthly-payment">
          Monthly Payment: {} EUR
        </Typography>
        <Typography data-testid="total-payment">
          Total Payment: {} EUR
        </Typography>
      </Box>
    </Paper>
  );
};

export default LoanResults;
