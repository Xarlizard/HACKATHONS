import React, { useState } from "react";
import { Box, Typography } from "@mui/material";
// TODO: Import all the necessary components.

const LoanCalculator = () => {
  const [monthlyPayment, setMonthlyPayment] = useState(null);
  const [totalPayment, setTotalPayment] = useState(null);

  // TODO: Check if `monthlyPayment` and `totalPayment` are valid.
  const showResults = false;

  // TODO: Implement the calculation logic to compute `monthlyPayment` and `totalPayment`.
  const handleCalculate = (amount, rate, duration) => {};

  // TODO: Pass the necessary props to components.
  return (
    <Box p={3} width="100%">
      <Typography variant="h4" mb={4}>
        Loan Calculator
      </Typography>
      <LoanForm onCalculate={true} />
      {showResults && (<LoanResults monthlyPayment={} totalPayment={} />)}
    </Box>
  );
};

export default LoanCalculator;
