import React, { useState } from "react";
import { TextField, Button, MenuItem, Typography, Box } from "@mui/material";

const CurrencyForm = ({ currencies, onConvert }) => {
  const [amount, setAmount] = useState(null);
  const [selectedCurrency, setSelectedCurrency] = useState("");
  const [error, setError] = useState("");

  const handleConvert = () => {
    // TODO: Validate that `amount` is a positive number and `selectedCurrency` is selected. Show an error message if validation fails.
    onConvert(amount, selectedCurrency);
  };

  // TODO: Bind the correct values and use appropriate functions for each component.
  return (
    <Box display="flex" flexDirection="column" gap={2}>
      <TextField
        type=""
        label="Amount"
        variant="outlined"
        value={}
        onChange={(e) => setAmount(e.target.value)}
        data-testid="amount-input"
      />
      <TextField
        select
        label="Currency"
        value={}
        onChange={}
        data-testid="currency-select"
      >
        {currencies.map((currency) => (
          <MenuItem key={currency} value={currency} data-testid={`currency-option-${currency}`}>
            {currency}
          </MenuItem>
        ))}
      </TextField>
      <Button
        variant="contained"
        color="primary"
        onClick={}
        data-testid="convert-button"
        sx={{ width: 200 }}
      >
        Convert
      </Button>
      {error && (<Typography color="error" data-testid="error-message">{}</Typography>)}
    </Box>
  );
};

export default CurrencyForm;
