import React, { useState } from "react";
import { Box, Typography } from "@mui/material";
// TODO: Import all necessary components and hooks.

const CurrencyConverter = () => {
  const [conversion, setConversion] = useState(null);
  const [fee, setFee] = useState(null);
  const [conversionError, setConversionError] = useState("");

  const { data: rates, isLoading, error: fetchError } = useFetch("/data/exchangeRates.json");

  // TODO: Extract the list of available currencies from `rates.toUSD` once data is fetched.
  const currencies = [];

  // TODO: Check if `conversion` and `fee` are not null.
  const showResults = false;

  // TODO: Combine `conversionError` and `fetchError` into a single error message to display.
  const error = '';

  // TODO: Implement the conversion logic to calculate `conversion` and `fee`.
  const handleConvert = (amount, currency) => {};

  // TODO: Pass the necessary props to components.
  return (
    <Box p={3} width="100%">
      <Typography variant="h4" mb={4}>
        Currency Converter
      </Typography>
      {isLoading ? (
        { /* TODO: Add a LoadingSpinner component to indicate data is being fetched.*/ }
        
      ) : (
        <CurrencyForm currencies={} onConvert={} />
      )}
      {showResults && (<ConversionResults conversion={} fee={} />)}
      {error && (<Typography color="error" data-testid="error-message">{}</Typography>)}
    </Box>
  );
};

export default CurrencyConverter;
