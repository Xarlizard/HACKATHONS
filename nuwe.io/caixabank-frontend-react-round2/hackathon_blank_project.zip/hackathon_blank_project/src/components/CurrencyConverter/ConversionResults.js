import React from "react";
import { Box, Typography, Paper } from "@mui/material";

const ConversionResults = ({ conversion, fee }) => {
  // TODO: Display `conversion` and `fee` formatted to two decimal places.
  return (
    <Paper elevation={3} sx={{ mt: 2 }} data-testid="conversion-results">
      <Box p={2}>
        <Typography variant="h6" gutterBottom>Results</Typography>
        <Typography data-testid="result-amount">
          {} EUR
        </Typography>
        <Typography data-testid="fee-applied">
          Fee Applied: {} EUR
        </Typography>
      </Box>
    </Paper>
  );
};

export default ConversionResults;
