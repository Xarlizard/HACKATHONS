import React from 'react';
import { Box, Typography } from '@mui/material';
import { Line } from 'react-chartjs-2';
import {
    Chart as ChartJS,
    CategoryScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Legend,
} from 'chart.js';
import { getRandomColor } from '../../helpers/getRandomColor';

ChartJS.register(
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Legend
);

const PortfolioChart = ({ assets }) => {
    const data = {
        labels: assets[0].history.map((entry) => entry.date), 
        datasets: [], // TODO: Map over `assets` to create datasets with labels, data, and colors. Use the `getRandomColor` function to assign a unique color to each dataset.
    };

    const options = {
        responsive: true,
        plugins: {
            legend: { display: true },
            title: {
                display: true,
                text: 'Portfolio Performance by Asset',
            },
        },
        scales: {
            x: {
                title: { display: true, text: 'Date' },
            },
            y: {
                title: { display: true, text: 'Value ($)' },
            },
        },
    };

    // TODO: Pass the required props to components.
    return (
        <Box mt={3} mb={3}>
            <Typography variant="h6" gutterBottom>
                Portfolio Performance by Asset
            </Typography>
            <Line data={} options={} />
        </Box>
    );
};

export default PortfolioChart;
