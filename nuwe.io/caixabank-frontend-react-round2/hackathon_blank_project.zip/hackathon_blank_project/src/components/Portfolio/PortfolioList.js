import React from 'react';
import { Box, Table, TableBody, TableCell, TableHead, TableRow, Paper } from '@mui/material';

const PortfolioList = ({ assets }) => {
    // TODO: Complete each TableCell values.
    return (
        <Box p={3}>
            <Paper>
                <Table data-testid="portfolio-table">
                    <TableHead>
                        <TableRow>
                            <TableCell>Asset</TableCell>
                            <TableCell>Type</TableCell>
                            <TableCell>{}</TableCell>
                            <TableCell>{}</TableCell>
                            <TableCell>{}</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {assets.map(asset => (
                            <TableRow key={asset.id} data-testid="asset-row">
                                <TableCell>{asset.name}</TableCell>
                                <TableCell>{asset.type}</TableCell>
                                <TableCell>{}</TableCell>
                                <TableCell>{}%</TableCell>
                                <TableCell>{}%</TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </Paper>
        </Box>
    );
};

export default PortfolioList;
