import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Container,
  Select,
  MenuItem,
  Paper,
  List,
  ListItem,
  ListItemText,
  Divider,
  CircularProgress,
} from "@mui/material";

const generateAssets = () => {
  const assetTypes = ["Stocks", "Crypto", "Funds"];
  return Array.from({ length: 10000 }, (_, index) => ({
    id: index + 1,
    name: `Asset ${index + 1}`,
    type: assetTypes[Math.floor(Math.random() * assetTypes.length)],
    value: Math.floor(Math.random() * 10000) + 100,
    dailyChange: Math.random() * 10 - 5,
    history: Array.from({ length: 30 }, (_, day) => ({
      date: new Date(Date.now() - day * 24 * 60 * 60 * 1000).toISOString(),
      value: Math.floor(Math.random() * 10000) + 100,
    })),
  }));
};

const App = () => {
  const [assets, setAssets] = useState([]);
  const [selectedAsset, setSelectedAsset] = useState(null);
  const [filter, setFilter] = useState("All");
  const [sortType, setSortType] = useState("Name");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setAssets(generateAssets());
    setLoading(false);
  }, []);

  const filteredAssets = assets.filter((asset) => {
    if (filter === "All") return true;
    return asset.type === filter;
  });

  const sortedAssets = filteredAssets.sort((a, b) => {
    if (sortType === "Name") return a.name.localeCompare(b.name);
    if (sortType === "Value") return b.value - a.value;
    if (sortType === "Daily Change") return b.dailyChange - a.dailyChange;
    return 0;
  });

  return (
    <Container maxWidth="lg" sx={{ padding: 4 }}>
      <Paper elevation={3} sx={{ padding: 4 }}>
        <Typography variant="h4" gutterBottom>
          Investment Assets
        </Typography>
        <Typography variant="h6" gutterBottom>
          Manage and Analyze Your Investments
        </Typography>

        <Box sx={{ display: "flex", justifyContent: "space-between", mb: 2 }}>
          <Box sx={{ display: "flex", alignItems: "center" }}>
            <Typography>Filter by Type:</Typography>
            <Select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              sx={{ marginLeft: 2, minWidth: 150 }}
            >
              <MenuItem value="All">All</MenuItem>
              <MenuItem value="Stocks">Stocks</MenuItem>
              <MenuItem value="Crypto">Crypto</MenuItem>
              <MenuItem value="Funds">Funds</MenuItem>
            </Select>
          </Box>
          <Box sx={{ display: "flex", alignItems: "center" }}>
            <Typography>Sort by:</Typography>
            <Select
              value={sortType}
              onChange={(e) => setSortType(e.target.value)}
              sx={{ marginLeft: 2, minWidth: 150 }}
            >
              <MenuItem value="Name">Name</MenuItem>
              <MenuItem value="Value">Value</MenuItem>
              <MenuItem value="Daily Change">Daily Change</MenuItem>
            </Select>
          </Box>
        </Box>

        {loading ? (
          <CircularProgress />
        ) : (
          <List sx={{ maxHeight: 400, overflowY: "auto" }}>
            {sortedAssets.map((asset) => (
              <React.Fragment key={asset.id}>
                <ListItem button onClick={() => setSelectedAsset(asset)}>
                  <ListItemText
                    primary={`ID: ${asset.id} | Name: ${asset.name} | Type: ${asset.type}`}
                    secondary={`Value: $${asset.value.toFixed(
                      2
                    )} | Daily Change: ${asset.dailyChange.toFixed(2)}%`}
                  />
                </ListItem>
                <Divider />
              </React.Fragment>
            ))}
          </List>
        )}

        {selectedAsset && (
          <Box
            sx={{ mt: 4, p: 3, backgroundColor: "#f1f1f1", borderRadius: 1 }}
          >
            <Typography variant="h6">Asset Details</Typography>
            <Typography>Name: {selectedAsset.name}</Typography>
            <Typography>Type: {selectedAsset.type}</Typography>
            <Typography>Value: ${selectedAsset.value.toFixed(2)}</Typography>
            <Typography>
              Daily Change: {selectedAsset.dailyChange.toFixed(2)}%
            </Typography>
            <List sx={{ mt: 2 }}>
              {selectedAsset.history.map((entry, index) => (
                <ListItem key={index}>
                  <ListItemText
                    primary={`Date: ${new Date(
                      entry.date
                    ).toLocaleDateString()} | Value: $${entry.value.toFixed(
                      2
                    )}`}
                  />
                </ListItem>
              ))}
            </List>
          </Box>
        )}
      </Paper>
    </Container>
  );
};

export default App;
