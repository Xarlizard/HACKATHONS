import React, { useState } from "react";
import {
  Box,
  Typography,
  MenuItem,
  FormControl,
  Select,
  Container,
} from "@mui/material";
import PortfolioList from "./PortfolioList";
// TODO: Import all the necessary components and hooks.

const Portfolio = () => {
  const [filter, setFilter] = useState("All");

  // TODO: Fetch the data from "/data/investments.json".
  const { data, isLoading, error } = useFetch("");

  // TODO: Filter the list of assets from `data.assets` based on the selected `filter`.
  const filteredAssets = [];

  // TODO: Determine whether to show the data, considering `isLoading`, `error`, and `filteredAssets`.
  const showAssets = false;

  // TODO: Implement the function to update the `filter` state when the user changes the selection.
  const handleFilterChange = (e) => {};

  // TODO: Pass the required props to components and assign the correct `value` to each MenuItem based on the filter type.
  return (
    <Container maxWidth="lg">
      <Box p={3}>
        <Typography variant="h4" gutterBottom>
          Investment Portfolio
        </Typography>
        <FormControl fullWidth variant="outlined" margin="normal">
          <Select value={} onChange={} data-testid="filter-select">
            <MenuItem value={}>All</MenuItem>
            <MenuItem value={}>Stocks</MenuItem>
            <MenuItem value={}>Crypto</MenuItem>
            <MenuItem value={}>Funds</MenuItem>
          </Select>
        </FormControl>
        {showAssets ? (
          <>
            <PortfolioChart assets={} />
            <PortfolioList assets={} />
          </>
        ) : (
          // TODO: Add a `LoadingSpinner` component to indicate loading.
        )}
        {error && (
          <Typography color="error" data-testid="error-message">
            {}
          </Typography>
        )}
      </Box>
    </Container>
  );
};

export default Portfolio;
