package com.hackathon.blockchain.service;

public class WalletService {

}