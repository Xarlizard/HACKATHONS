package com.hackathon.blockchain.config;

public class SecurityConfig {

}
