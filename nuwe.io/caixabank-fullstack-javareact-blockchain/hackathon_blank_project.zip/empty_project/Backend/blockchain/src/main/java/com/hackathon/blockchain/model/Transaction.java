package com.hackathon.blockchain.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString(exclude = "block")
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "sender_wallet_id", nullable = false)
    private Wallet senderWallet;

    @ManyToOne
    @JoinColumn(name = "receiver_wallet_id", nullable = false)
    private Wallet receiverWallet;

    @Column(nullable = false)
    private String assetSymbol;

    @Column(nullable = false)
    private double amount;

    @Column(nullable = false)
    private double pricePerUnit;

    @Column(nullable = false)
    private String type;

    @Temporal(TemporalType.TIMESTAMP)
    private Date timestamp = new Date();
    
    @Column(nullable = false)
    private String status = "PENDING";

    @Column(nullable = false)
    private double fee = 0.0;

    @ManyToOne
    @JoinColumn(name = "block_id")
    @JsonBackReference
    private Block block;
}
