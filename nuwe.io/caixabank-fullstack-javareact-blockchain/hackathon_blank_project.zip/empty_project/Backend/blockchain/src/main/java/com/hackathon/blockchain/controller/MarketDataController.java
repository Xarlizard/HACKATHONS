package com.hackathon.blockchain.controller;

public class MarketDataController {

}
