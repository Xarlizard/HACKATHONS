package com.hackathon.blockchain.dto;

public class LoginRequest {

}
