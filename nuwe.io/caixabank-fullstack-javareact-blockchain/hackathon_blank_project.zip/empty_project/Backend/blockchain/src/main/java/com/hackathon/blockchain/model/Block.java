package com.hackathon.blockchain.model;

import jakarta.persistence.*;
import lombok.*;
import java.util.Date;
import java.util.List;
import org.apache.commons.codec.digest.DigestUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString(exclude = "transactions")
public class Block {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "block_index")
    private int blockIndex;

    private long timestamp;

    private String previousHash;

    private int nonce;

    private String hash;

    private boolean isGenesis;

    @OneToMany(mappedBy = "block", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JsonIgnore
    private List<Transaction> transactions;

    public Block(int blockIndex, List<Transaction> transactions, String previousHash, boolean isGenesis) {
        this.blockIndex = blockIndex;
        this.transactions = transactions;
        this.previousHash = previousHash;
        this.timestamp = new Date().getTime();
        this.nonce = 0;
        this.isGenesis = isGenesis;
        this.hash = calculateHash();
    }

    public String calculateHash() {
        return null;
    }

    public void mineBlock(int difficulty) {
        
    }
}
