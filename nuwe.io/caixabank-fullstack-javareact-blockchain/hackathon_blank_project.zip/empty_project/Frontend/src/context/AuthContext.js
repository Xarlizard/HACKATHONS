import React, { createContext, useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { checkUserSession, logoutUser } from "../services/authService";

export const AuthContext = 

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const navigate = useNavigate();

  const checkSession = async () => {

  };

  const handleLogin = async (userData) => {

  };

  const handleLogout = async () => {

  };

  useEffect(() => {
    checkSession();
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading, error, handleLogout, handleLogin }}>
      {children}
    </AuthContext.Provider>
  );
};
