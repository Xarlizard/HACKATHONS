import React, { createContext, useState, useEffect } from "react";
import { getMarketPrices } from "../services/marketService";

export const MarketContext = createContext();

export const MarketProvider = ({ children }) => {
  const [prices, setPrices] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const fetchPrices = async () => {

  };

  useEffect(() => {
    fetchPrices();
    const interval = 
    return () => clearInterval(interval);
  }, []);

  return (
    <MarketContext.Provider value={{ prices, loading, error }}>
      {children}
    </MarketContext.Provider>
  );
};
