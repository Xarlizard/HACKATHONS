import { fetchData } from "../utils/fetchData";

const BASE_URL = "/blockchain";

export const getBlockchain = async () => {

};

export const mineBlock = async () => {

};
