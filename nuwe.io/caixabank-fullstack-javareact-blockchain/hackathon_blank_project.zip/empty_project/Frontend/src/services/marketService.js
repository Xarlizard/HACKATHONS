import { fetchData } from "../utils/fetchData";

const BASE_URL = "/market";

export const getMarketPrices = async () => {

};
