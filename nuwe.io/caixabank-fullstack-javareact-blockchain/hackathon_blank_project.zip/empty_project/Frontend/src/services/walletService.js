import { fetchData } from "../utils/fetchData";

const BASE_URL = "/wallet";

export const getWalletBalance = async () => {

};

export const getWalletTransactions = async () => {

};

export const createWallet = async () => {

};

export const buyUSDT = async (amount) => {

};

export const buyAsset = async (symbol, quantity) => {

};

export const sellAsset = async (symbol, quantity) => {

};
