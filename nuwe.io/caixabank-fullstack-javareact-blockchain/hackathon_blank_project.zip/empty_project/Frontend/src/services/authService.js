import { fetchData } from "../utils/fetchData";

const BASE_URL = "/auth";

export const checkUserSession = async () => {

};

export const registerUser = async (userData) => {

};

export const loginUser = async (credentials) => {

};

export const logoutUser = async () => {

};
