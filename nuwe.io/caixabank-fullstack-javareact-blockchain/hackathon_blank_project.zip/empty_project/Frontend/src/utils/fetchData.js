export async function fetchData(endpoint, method, body = null) {
  const API_BASE_URL = "http://localhost:3000";
  const url = `${API_BASE_URL}${endpoint}`;

  const options = {

  };

  if (body) {

  }

  const response = 
  
  const result =

  if (!response.ok) {
    throw new Error(result.message || "Error fetching data");
  }

  return result;
}
