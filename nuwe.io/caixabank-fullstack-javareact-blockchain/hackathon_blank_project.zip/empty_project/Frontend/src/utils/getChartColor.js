export function getChartColor(priceData) {

}
