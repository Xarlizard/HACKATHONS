import React, { useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate } from "react-router-dom";
import { Box, CircularProgress } from "@mui/material";
import DashboardView from "./components/DashboardView";
import TradingView from "./components/TradingView";
import AuthView from "./components/AuthView";
import { useAuth } from "./hooks/useAuth";
import { AuthProvider } from "./context/AuthContext";
import { MarketProvider } from "./context/MarketContext";

function AppContent() {
  const { user, loading } = useAuth();

  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !user) {
      navigate("/", { replace: true });
    }
  }, [loading, user, navigate]);

  if (loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh" }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Routes>
      <Route path="/" element={user ? <Navigate to="/dashboard" replace /> : <AuthView />} />
      <Route
        path="/dashboard"
        element={
          user ? (
            <MarketProvider>
              <DashboardView />
            </MarketProvider>
          ) : (
            <Navigate to="/" replace />
          )
        }
      />
      <Route
        path="/trade/:symbol"
        element={
          user ? (
            <MarketProvider>
              <TradingView />
            </MarketProvider>
          ) : (
            <Navigate to="/" replace />
          )
        }
      />
    </Routes>
  );
}

export default function App() {
  return (
    <Router>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </Router>
  );
}
