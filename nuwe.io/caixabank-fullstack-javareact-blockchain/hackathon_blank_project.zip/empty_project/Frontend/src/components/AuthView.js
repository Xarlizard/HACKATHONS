import React, { useState, useEffect } from "react";
import { Box, Paper, Tabs, Tab, TextField, Button, Typography } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { loginUser, registerUser } from "../services/authService";
import { useAuth } from "../hooks/useAuth";

export default function AuthView() {
  const {} = useAuth();

  const navigate = useNavigate();

  const [tabIndex, setTabIndex] = useState(0);
  const [formData, setFormData] = useState({ username: "", email: "", password: "" });
  const [formErrors, setFormErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [apiError, setApiError] = useState("");

  useEffect(() => {
    if (user) {

    }
  }, [user, navigate]);

  const validate = () => {

  };

  const handleSubmit = async (e) => {

  };

  return (
    <Box data-testid="auth-view" sx={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh", bgcolor: "#f2f2f2" }}>
      <Paper sx={{ width: 400, padding: 4, borderRadius: 2 }}>
        <Box display="flex" justifyContent="center" py={2}>
          <img src="/caixabank-tech-logo.png" alt="CaixaBank logo" style={{ width: 200, marginRight: "20px" }} />
          <Typography variant="h5" align="center" sx={{ mb: 2 }} data-testid="auth-title">
            The Hack is ON
          </Typography>
        </Box>
        <hr />
        <Tabs sx={{ mt: 1 }} value={tabIndex} onChange={} centered data-testid="auth-tabs">
          <Tab label="Login" data-testid="login-tab" />
          <Tab label="Register" data-testid="register-tab" />
        </Tabs>
        <Box component="form" onSubmit={} sx={{ mt: 2 }} data-testid="auth-form">
          {formErrors && (
            <Typography sx={{ my: 2 }} color="error" data-testid="error-message">
              {}
            </Typography>
          )}
          <TextField
            fullWidth
            label="Username"
            value={}
            onChange={}
            error={}
            helperText={}
            sx={{ mb: 2 }}
            data-testid="username-input"
          />
          {tabIndex === 1 && (
            <TextField
              fullWidth
              label="Email"
              value={}
              onChange={}
              error={}
              helperText={}
              sx={{ mb: 2 }}
              data-testid="email-input"
            />
          )}
          <TextField
            fullWidth
            label="Password"
            type="password"
            value={}
            onChange={}
            error={}
            helperText={}
            sx={{ mb: 2 }}
            data-testid="password-input"
          />
          {apiError && (
            <Typography color="error" sx={{ my: 2 }} data-testid="api-error">
              {}
            </Typography>
          )}
          <Button type="submit" variant="contained" color="info" fullWidth sx={{ mt: 2 }} disabled={loading} data-testid="submit-button">
            {tabIndex === 0 ? "Login" : "Register"}
          </Button>
        </Box>
      </Paper>
    </Box>
  );
}
