import React, { useState, useEffect } from "react";
import { Line } from "react-chartjs-2";
import { Box } from "@mui/material";
import { Chart as ChartJS, LineElement, PointElement, CategoryScale } from "chart.js";
import { useMarket } from "../hooks/useMarket";
import { getChartColor } from "../utils/getChartColor";

ChartJS.register(LineElement, PointElement, LinearScale, CategoryScale);

export default function MarketChart({ asset, width = 880, height = 400, responsive = true, showLabels = true, showGrid = true, "data-testid": testId }) {
  const { prices } = useMarket();
  const [dataPoints, setDataPoints] = useState([]);
  const chartColor = getChartColor(dataPoints);

  useEffect(() => {
    if (prices && prices[asset]) {
      const now = new Date();
      const timeLabel = `${now.getHours()}:${now.getMinutes()}:${now.getSeconds()}`;
  
      setDataPoints((prevData) => {
        const newData = [...prevData, { time: timeLabel, price: prices[asset] }];
        return newData.slice(-10);
      });
    }
  }, [prices, asset]);

  const chartData = {
    labels: dataPoints.map((point) => point.time),
    datasets: [
      {
        label: `${asset}/USDT`,
        data: dataPoints.map((point) => point.price),
        borderColor: chartColor,
        backgroundColor: "rgba(255, 255, 255, 0.1)",
        borderWidth: 2,
        pointRadius: 0,
        pointHoverRadius: 0,
      },
    ],
  };

  const options = {
    responsive,
    animation: false,
    scales: {
      x: {
        display: showLabels,
        grid: { display: showGrid },
      },
      y: {
        position: "right",
        display: showLabels,
        grid: { display: showGrid },
      },
    },
  };

  return (
    <Box sx={{ width, height }}>
      <Line data={chartData} options={options} data-testid={testId} />
    </Box>
  );
}
