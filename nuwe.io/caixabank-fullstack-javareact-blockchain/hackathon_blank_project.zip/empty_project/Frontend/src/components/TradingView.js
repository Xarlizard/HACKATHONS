import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Box, Button, Typography } from "@mui/material";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import ChartSection from "./ChartSection";
import TransactionsTable from "./TransactionsTable";
import AssetTradingPanel from "./AssetTradingPanel";
import Navbar from "./Navbar";
import LoadingSpinner from "./LoadingSpinner";
import { getWalletBalance, getWalletTransactions } from "../services/walletService";
import { mineBlock } from "../services/blockchainService";

export default function TradingView() {
  const {} = useParams();

  const [asset, setAsset] = useState(symbol);
  const [walletData, setWalletData] = useState(null);
  const [transactions, setTransactions] = useState({ sent: [], received: [] });
  const [loading, setLoading] = useState(true);
  const [apiError, setApiError] = useState("");

  const fetchWallet = async () => {

  };

  const mineBlockAndFetchWallet = async () => {

  };

  const handleGoToDashboard = () => {

  };

  useEffect(() => {
    setAsset(symbol.toUpperCase());
  }, [symbol]);

  useEffect(() => {
    fetchWallet();
  }, []);

  return (
    <Box sx={{ minHeight: "100vh", bgcolor: "#f2f2f2" }}>
      <Navbar />
      <Box sx={{ display: "flex", justifyContent: "center", p: 3 }}>
        <Box sx={{ display: "flex", flexDirection: "column", width: 1200 }}>
          {loading ? (
            <LoadingSpinner data-testid="trading-view-loading" />
          ) : (
            <>
              <Button startIcon={<ArrowBackIcon />} data-testid="go-back" sx={{ mb: 2, width: 230 }} onClick={}>
                Go to Dashboard
              </Button>
              {!walletData || apiError ? (
                <Box sx={{ p: 3, textAlign: "center" }}>
                  <Typography data-testid="trading-view-error" variant="h6" color="error">
                    {}
                  </Typography>
                </Box>
              ) : (
                <>
                  <Box sx={{ display: "flex" }}>
                    <ChartSection asset={} data-testid="chart-section" />
                    <AssetTradingPanel asset={} usdtBalance={} assetBalance={} onTransactionComplete={mineBlockAndFetchWallet} />
                  </Box>
                  <TransactionsTable asset={} loading={} transactions={} error={} />
                </>
              )}
            </>
          )}
        </Box>
      </Box>
    </Box>
  );
}
