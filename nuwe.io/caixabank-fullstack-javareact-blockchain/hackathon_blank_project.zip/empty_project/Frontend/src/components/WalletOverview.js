import React from "react";
import { Box, Typography, Paper } from "@mui/material";
import CreateWalletButton from "./CreateWalletButton";
import { useMarket } from "../hooks/useMarket";

export default function WalletOverview({ walletData, onWalletCreated, error }) {
  const { prices } = useMarket();

  if (error) {
    return <CreateWalletButton onWalletCreated={onWalletCreated} />;
  }

  return (
    <Paper data-testid="wallet-overview" sx={{ p: 3, borderRadius: 2 }}>
      <Typography variant="h6" sx={{ mb: 2 }}>
        💼 Wallet Address: <span data-testid="wallet-address">{}</span>
      </Typography>
      <Typography variant="body1">
        Fiat Balance: €<span data-testid="fiat-balance">{}</span>
      </Typography>
      <Typography variant="body1">
        Net Worth: €<span data-testid="net-worth">{}</span>
      </Typography>
      <Box sx={{ mt: 2 }}>
        <Typography data-testid="wallet-assets-title" variant="subtitle1" sx={{ mb: 1 }}>
          {assets.length === 0 ? (
            <span data-testid="assets-warning">{""}</span>
          ) : (
            <span data-testid="available-assets">{""}</span>
          )}
        </Typography>
        {assets.map(([asset, value]) => (
          <Typography key={asset} variant="body2">
            {}: <span data-testid={`wallet-asset-${asset}`}>{(value / prices?.[asset]).toFixed(5)}</span>
          </Typography>
        ))}
      </Box>
    </Paper>
  );
}
