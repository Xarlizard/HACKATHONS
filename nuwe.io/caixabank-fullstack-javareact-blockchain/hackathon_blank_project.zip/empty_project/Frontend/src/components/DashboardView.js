import React, { useEffect, useState } from "react";
import { Box } from "@mui/material";
import WalletOverview from "./WalletOverview";
import BuyUSDT from "./BuyUSDT";
import TradingPairs from "./TradingPairs";
import Navbar from "./Navbar";
import BlockchainExplorer from "./BlockchainExplorer";
import LoadingSpinner from "./LoadingSpinner";
import { getWalletBalance } from "../services/walletService";

export default function DashboardView() {
  const [walletData, setWalletData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [apiError, setApiError] = useState("");
  const [walletUpdated, setWalletUpdated] = useState(false);

  const fetchWalletBalance = async () => {

  };

  const onWalletCreated = () => {
    setWalletUpdated(true);
  };

  useEffect(() => {
    fetchWalletBalance();
    if (walletUpdated) setWalletUpdated(false);
  }, [walletUpdated]);

  return (
    <Box data-testid="dashboard-view" sx={{ minHeight: "100vh", backgroundColor: "#f2f2f2" }}>
      <Navbar />
      <Box display="flex" justifyContent="center">
        <Box data-testid="dashboard-content" sx={{ display: "flex", flexDirection: "column", gap: 2, p: 3, width: 1200 }}>
          {loading ? (
            <LoadingSpinner data-testid="dashboard-loading" />
          ) : (
            <>
              <WalletOverview walletData={} error={} onWalletCreated={} />
              {!apiError && <BuyUSDT cashBalance={} onTransactionComplete={} />}
              <TradingPairs />
              <BlockchainExplorer />
            </>
          )}
        </Box>
      </Box>
    </Box>
  );
}
