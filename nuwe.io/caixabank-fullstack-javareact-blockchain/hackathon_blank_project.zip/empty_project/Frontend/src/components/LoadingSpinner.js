import React from "react";
import { Box, CircularProgress } from "@mui/material";

export default function LoadingSpinner({ "data-testid": testId }) {
  return (
    <Box data-testid={testId} sx={{ display: "flex", width: "100%", height: "100%", justifyContent: "center", alignItems: "center" }}>
      <CircularProgress />
    </Box>
  );
}
