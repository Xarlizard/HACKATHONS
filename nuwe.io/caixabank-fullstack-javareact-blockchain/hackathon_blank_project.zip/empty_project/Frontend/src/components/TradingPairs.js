import React from "react";
import { useNavigate } from "react-router-dom";
import { Paper, Typography, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Avatar, Box, Tooltip } from "@mui/material";
import MonetizationOnIcon from "@mui/icons-material/MonetizationOn";
import MarketChart from "./MarketChart";
import LoadingSpinner from "./LoadingSpinner";
import { useMarket } from "../hooks/useMarket";

export default function TradingPairs() {
  const navigate = useNavigate();

  const { prices, loading } = useMarket();

  const pairs = 

  return (
    <Paper data-testid="trading-pairs" sx={{ p: 2, borderRadius: 2 }}>
      <Typography variant="h6" sx={{ mb: 2 }}>
        💱 USDT Trading Pairs
      </Typography>
      {loading ? (
        <LoadingSpinner data-testid="market-prices-loader" />
      ) : (
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell sx={{ width: "75%" }}>Pair</TableCell>
                <TableCell sx={{ width: "15%", textAlign: "center" }}>Price</TableCell>
                <TableCell sx={{ width: "10%", textAlign: "center" }}>Chart</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {pairs.map((pair) => (
                <Tooltip arrow title={`Trade ${pair.label}`} key={pair.symbol} placement="top">
                  <TableRow key={} hover onClick={() => navigate(`/trade/${pair.symbol}`)} sx={{ cursor: "pointer", height: 56 }} data-testid={`trade-${pair.symbol.toLowerCase()}`}>
                    <TableCell>
                      <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                        <Avatar alt={pair.symbol} sx={{ width: 30, height: 30, bgcolor: "#00a1e0" }}>
                          <MonetizationOnIcon fontSize="small" />
                        </Avatar>
                        {pair.label}
                      </Box>
                    </TableCell>
                    <TableCell data-testid={`${pair.symbol.toLowerCase()}-price`} align="center">{`$${}`}</TableCell>
                    <TableCell align="center" sx={{ width: "100px", pl: 2 }}>
                      <MarketChart data-testid={`${pair.symbol.toLowerCase()}-chart`} asset={} width={80} height={40} responsive={true} showLabels={false} showGrid={false} />
                    </TableCell>
                  </TableRow>
                </Tooltip>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Paper>
  );
}
