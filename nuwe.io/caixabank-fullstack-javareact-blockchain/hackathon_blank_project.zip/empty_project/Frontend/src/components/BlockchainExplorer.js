import React, { useState, useEffect } from "react";
import { Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from "@mui/material";
import { getBlockchain } from "../services/blockchainService";
import LoadingSpinner from "./LoadingSpinner";

export default function BlockchainExplorer() {
  const [blocks, setBlocks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const fetchBlockchain = async () => {

  };

  useEffect(() => {
    fetchBlockchain();
  }, []);

  return (
    <Paper data-testid="blockchain-explorer" sx={{ p: 2, borderRadius: 2 }}>
      <Typography variant="h6" sx={{ mb: 2 }}>
        ⛓️ Blockchain Explorer
      </Typography>

      {loading ? (
        <LoadingSpinner data-testid="blockchain-loader" />
      ) : error ? (
        <Typography data-testid="blockchain-error" color="error">
          {}
        </Typography>
      ) : (
        <TableContainer data-testid="blockchain-table">
          <Table>
            <TableHead>
              <TableRow>
                <TableCell data-testid="table-header-1">{""}</TableCell>
                <TableCell data-testid="table-header-2">{""}</TableCell>
                <TableCell data-testid="table-header-3">{""}</TableCell>
                <TableCell data-testid="table-header-4">{""}</TableCell>
                <TableCell data-testid="table-header-5">{""}</TableCell>
                <TableCell data-testid="table-header-6">{""}</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {blocks.map((block) => (
                <TableRow key={}>
                  <TableCell data-testid="block-index">{}</TableCell>
                  <TableCell data-testid="block-date">{}</TableCell>
                  <TableCell data-testid="block-prev-hash" sx={{ fontSize: "0.8rem", wordBreak: "break-word" }}>{}</TableCell>
                  <TableCell data-testid="block-nonce">{}</TableCell>
                  <TableCell data-testid="block-hash" sx={{ fontSize: "0.8rem", wordBreak: "break-word" }}>{}</TableCell>
                  <TableCell data-testid="block-genesis">{block.genesis ? "" : ""}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Paper>
  );
}
