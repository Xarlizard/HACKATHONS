import React, { useState } from "react";
import { Paper, TextField, Button, Typography } from "@mui/material";
import { buyUSDT } from "../services/walletService";

export default function BuyUSDT({ cashBalance, onTransactionComplete }) {
  const [amount, setAmount] = useState("");
  const [loading, setLoading] = useState(false);
  const [apiError, setApiError] = useState("");

  const handleBuy = async () => {

  };

  return (
    <Paper data-testid="buy-usdt" sx={{ gap: 2, p: 2, borderRadius: 2 }}>
      <Typography variant="h6" sx={{ mb: 1 }}>💵 Buy USDT with Fiat Balance</Typography>
      <TextField data-testid="buy-usdt-input" label="Amount (€)" sx={{ mb: 2 }} type="number" value={} onChange={} fullWidth />
      {apiError && (
        <Typography sx={{ mb: 2 }} data-testid="buy-usdt-error" color="error">
          {}
        </Typography>
      )}
      <Button data-testid="buy-usdt-button" variant="contained" color="info" onClick={} disabled={}>
        Buy USDT
      </Button>
    </Paper>
  );
}
