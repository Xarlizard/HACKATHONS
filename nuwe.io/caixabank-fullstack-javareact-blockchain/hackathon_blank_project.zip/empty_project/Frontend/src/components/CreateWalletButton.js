import React, { useState } from "react";
import { Button, Box, Typography } from "@mui/material";
import { createWallet } from "../services/walletService";

export default function CreateWalletButton({ onWalletCreated }) {
  const [loading, setLoading] = useState(false);
  const [apiError, setApiError] = useState("");

  const handleCreateWallet = async () => {

  };

  return (
    <Box data-testid="create-wallet" sx={{ p: 3, textAlign: "center" }}>
      <Typography data-testid="create-wallet-title" variant="h6" sx={{ mb: 2 }}>🚀 You don't have a wallet yet!</Typography>
      {apiError && (
        <Typography sx={{ mb: 2 }} data-testid="create-wallet-error" color="error">
          {}
        </Typography>
      )}
      <Button data-testid="create-wallet-button" variant="contained" color="primary" onClick={} disabled={}>
        Create Wallet
      </Button>
    </Box>
  );
}
