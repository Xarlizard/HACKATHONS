import React from "react";
import { Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from "@mui/material";
import { filterTransactions } from "../utils/filterTransactions";
import LoadingSpinner from "./LoadingSpinner";

export default function TransactionsTable({ asset, transactions, loading, error }) {
  const filteredTransactions = filterTransactions(transactions, asset);

  return (
    <Paper sx={{ mt: 2, p: 2 }}>
      <Typography variant="h6" sx={{ mb: 2 }}>
        Recent Transactions {asset ? `(${asset})` : ""}
      </Typography>

      {loading ? (
        <LoadingSpinner data-testid="transactions-loader" />
      ) : error ? (
        <Typography data-testid="transactions-error" color="error">{}</Typography>
      ) : (
        <TableContainer data-testid="transactions-table">
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Type</TableCell>
                <TableCell>Asset</TableCell>
                <TableCell>Amount</TableCell>
                <TableCell>Price</TableCell>
                <TableCell>Timestamp</TableCell>
                <TableCell>Status</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredTransactions.length === 0 ? (
                <TableRow>
                  <TableCell data-testid="transactions-not-found" colSpan={6} align="center">
                    {""}
                  </TableCell>
                </TableRow>
              ) : (
                filteredTransactions.map((tx) => (
                  <TableRow key={tx.id}>
                    <TableCell data-testid="transactions-table-type" sx={{ color: tx.type === "BUY" ? "" : "" }}>{tx.type}</TableCell>
                    <TableCell data-testid="transactions-table-symbol">{}</TableCell>
                    <TableCell data-testid="transactions-table-ammount">{}</TableCell>
                    <TableCell data-testid="transactions-table-price">${}</TableCell>
                    <TableCell data-testid="transactions-table-date">{}</TableCell>
                    <TableCell data-testid="transactions-table-status">{}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Paper>
  );
}
