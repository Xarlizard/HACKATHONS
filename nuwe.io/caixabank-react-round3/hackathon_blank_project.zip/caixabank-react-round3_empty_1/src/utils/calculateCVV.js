export const calculateCVV = (codes) => {};
