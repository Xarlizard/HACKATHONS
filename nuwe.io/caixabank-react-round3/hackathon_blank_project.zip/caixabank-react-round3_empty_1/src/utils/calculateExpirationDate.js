export const calculateExpirationDate = (cardNumber) => {};
