export const generateLuhnCardNumber = () => {};
