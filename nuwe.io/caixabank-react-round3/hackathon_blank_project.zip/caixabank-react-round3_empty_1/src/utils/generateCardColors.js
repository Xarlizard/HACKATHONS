export const generateCardColors = (cardNumber) => {};
