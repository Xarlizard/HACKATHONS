export const getNotch = (type, flipped) => {};
