import React, { useState, useContext } from "react";
import { Button, Typography, Box, Select, MenuItem } from "@mui/material";
import { CardsContext } from "../context/CardsContext";
import { generateLuhnCardNumber } from "../utils/generateLuhnCardNumber";
import { fetchCVV } from "../services/fetchCVV";
import { calculateCVV } from "../utils/calculateCVV";
import { calculateExpirationDate } from "../utils/calculateExpirationDate";

const CardGenerator = () => {
  const { cards, addCard } = useContext(CardsContext);

  const [selectedType, setSelectedType] = useState("credit");
  const [loading, setLoading] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const [error, setError] = useState("");

  const handleGenerateCard = async () => {
    const number = 
    const expiration = 
    const codes =  
    const cvv = calculateCVV(codes);

    addCard({ number, type: selectedType, expiration, cvv });

    const interval = setInterval(() => {}, 1000);
  };

  return (
    <Box sx={{ textAlign: "center", mt: 3, display: "flex", flexDirection: "column", alignItems: "center" }} data-testid="card-generator">
      <Typography variant="subtitle1" data-testid="card-type-label">
        Select Card Type:
      </Typography>
      <Select value={selectedType} size="small" sx={{ width: 250, mb: 2 }} onChange={(e) => setSelectedType(e.target.value)} data-testid="card-type-select">
        <MenuItem value="credit" data-testid="card-type-credit">{}</MenuItem>
        <MenuItem value="debit" data-testid="card-type-debit">{}</MenuItem>
        <MenuItem value="prepaid" data-testid="card-type-prepaid">{}</MenuItem>
      </Select>
      <Button variant="contained" color="info" onClick={} disabled={} aria-label="Generate new card" data-testid="generate-card-button">
        Generate Card
      </Button>
      {cooldown > 0 && (
        <Typography variant="caption" sx={{ display: "block", mt: 1, color: "gray" }} data-testid="cooldown-timer">
          You can generate a new card in {cooldown} seconds.
        </Typography>
      )}
      {error && (
        <Typography variant="caption" sx={{ display: "block", mt: 1, color: "error" }} data-testid="card-error-message">
          {}
        </Typography>
      )}
    </Box>
  );
};

export default CardGenerator;
