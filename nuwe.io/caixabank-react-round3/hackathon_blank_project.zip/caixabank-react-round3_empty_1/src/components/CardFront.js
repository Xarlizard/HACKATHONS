import React from "react";
import { Box, Typography } from "@mui/material";
import ContactlessIcon from "./ContactlessIcon";
import CardChip from "./CardChip";
import { getNotch } from "../utils/getNotch";

const CardFront = ({ number, type, expiration, font, background }) => {
  return (
    <Box
      sx={{
        position: "absolute",
        width: "100%",
        height: "100%",
        background: background,
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        alignItems: "center",
        color: "white",
        backfaceVisibility: "",
        borderRadius: "12px",
        clipPath: getNotch(type, false),
        padding: "20px",
      }}
      data-testid="card-front"
    >
      <Box sx={{ position: "absolute", top: 25, left: 20 }}>
        <img 
          src=
          alt="CaixaBank Tech logo" 
          style={{ width: 300 }} 
          data-testid="card-logo"
        />
      </Box>
      <Box sx={{ position: "absolute", top: "35%", left: 20, display: "flex", alignItems: "center" }}>
        <ContactlessIcon 
          sx={{ fontSize: 38, marginRight: 1, color: "white" }} 
          data-testid="contactless-icon" 
        />
        <CardChip data-testid="card-chip" />
      </Box>
      <Typography 
        sx={{ position: "absolute", fontWeight: "bold", textTransform: "uppercase", top: 30, right: 30, fontFamily: font }}
        data-testid="card-type"
      >
        {} CARD
      </Typography>
      <Typography 
        variant="h4" 
        sx={{ letterSpacing: 2, mt: 15.5, fontFamily: font }}
        data-testid="card-number"
      >
        {}
      </Typography>
      <Typography 
        variant="h5" 
        sx={{ letterSpacing: 2, fontFamily: font }}
        data-testid="card-holder"
      >
        JOHN DOE
      </Typography>
      <Typography 
        variant="body2" 
        sx={{ fontFamily: font }}
      >
        Exp: <span data-testid="card-expiration">{}</span>
      </Typography>
    </Box>
  );
};

export default CardFront;
