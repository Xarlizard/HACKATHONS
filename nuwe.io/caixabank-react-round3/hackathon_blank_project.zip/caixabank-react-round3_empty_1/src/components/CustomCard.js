import React, { useState } from "react";
import { Box, Card as MuiCard } from "@mui/material";
import CardFront from "./CardFront";
import CardBack from "./CardBack";
import CardEditControls from "./CardEditControls";
import { generateCardColors } from "../utils/generateCardColors";

const CustomCard = ({ id, number, type, expiration, cvv, removeCard }) => {
  const [flipped, setFlipped] = useState(false);

  const defaultBackground = 

  const [background, setBackground] = useState(defaultBackground);
  const [font, setFont] = useState("Arial");

  return (
    <Box sx={{ position: "relative", width: "100%" }} data-testid={`custom-card-${id}`}>
      <MuiCard
        sx={{
          width: "100%",
          height: 400,
          borderRadius: "12px",
          perspective: "1000px",
          cursor: "pointer",
          boxShadow: "none",
        }}
        onClick={() => setFlipped(!flipped)}
        data-testid={`custom-card-container-${id}`}
      >
        <Box
          sx={{
            width: "100%",
            height: "100%",
            position: "relative",
            transformStyle: "",
            transform: flipped ? "" : "",
            transition: "",
          }}
          data-testid={`custom-card-content-${id}`}
        >
          <CardFront 
            number={} 
            type={} 
            expiration={} 
            font={} 
            background={} 
          />
          <CardBack 
            cvv={} 
            type={} 
            background={} 
            font={} 
          />
        </Box>
      </MuiCard>
      <CardEditControls 
        background={} 
        setBackground={} 
        font={} 
        setFont={} 
        removeCard={} 
        id={} 
      />
    </Box>
  );
};

export default CustomCard;
