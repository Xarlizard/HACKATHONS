import React from "react";
import { Box, Button, Select, MenuItem, Typography } from "@mui/material";

const CardEditControls = ({ background, setBackground, font, setFont, removeCard, id }) => {
  return (
    <Box sx={{ display: "flex", justifyContent: "space-between", marginTop: 2 }} data-testid="card-edit-controls">
      <Box display="flex" alignItems="center">
        <Typography sx={{ mr: 1 }}>Color:</Typography>
        <input type="color" value={background} onChange={} style={{ width: 40, height: 40, border: "none", cursor: "pointer" }} data-testid="color-picker" />
      </Box>
      <Box display="flex" alignItems="center">
        <Typography sx={{ mr: 1 }}>Typography:</Typography>
        <Select size="small" value={font} onChange={} sx={{ width: 200 }} data-testid="font-selector">
          <MenuItem value=""></MenuItem>
          <MenuItem value=""></MenuItem>
          <MenuItem value=""></MenuItem>
        </Select>
      </Box>
      <Button variant="contained" color="error" onClick={} data-testid="remove-card-button">
        Remove card
      </Button>
    </Box>
  );
};

export default CardEditControls;
