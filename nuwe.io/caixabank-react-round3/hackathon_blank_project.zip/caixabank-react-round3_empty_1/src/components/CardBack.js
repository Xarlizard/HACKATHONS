import React from "react";
import { Box } from "@mui/material";
import { getNotch } from "../utils/getNotch";
import CardStripe from "./CardStripe";
import CVVBox from "./CVVBox";

const CardBack = ({ cvv, type, background, font }) => {
  return (
    <Box
      data-testid="card-back"
      sx={{
        position: "absolute",
        width: "100%",
        height: "100%",
        background: background,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        color: "white",
        transform: "",
        backfaceVisibility: "",
        borderRadius: "12px",
        clipPath: getNotch(type, true),
        padding: "20px",
        fontFamily: font,
      }}
    >
      <img
        data-testid="card-back-logo"
        src=
        alt="NUWE logo"
        style={{ width: 200, marginTop: 20 }}
      />
    </Box>
  );
};

export default CardBack;
