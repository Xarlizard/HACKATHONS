import React, { useContext } from "react";
import { Box } from "@mui/material";
import { CardsContext } from "../context/CardsContext";
import CustomCard from "./CustomCard";

const CardList = () => {
  const { cards, removeCard } = useContext(CardsContext);

  return (
    <Box data-testid="card-list-container">
      {cards.map((card) => (
        <Box my={4} key={} data-testid={`card-list-item-${card.id}`}>
          <CustomCard
            id={}
            number={}
            type={}
            expiration={}
            cvv={}
            removeCard={}
          />
        </Box>
      ))}
    </Box>
  );
};

export default CardList;
